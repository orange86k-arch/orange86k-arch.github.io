﻿# 싱글리니지 원클릭 (11-06) — 싱글리니지_원클릭.bat 이 부른다: Tailscale 설치·연결 → 게임 받기(처음 한 번) → 접속.
# 처음 설치하면 바탕 화면에 '싱글리니지 접속.bat'(다음부터 이것) 과 '싱글리니지 지우기.bat'(다 놀고 나서) 이 생긴다.
$HostIp  = '100.95.153.93'
$RelayUrl = 'https://orange86k-arch.github.io/singlelin-relay.exe'   # 설치가 막힌 PC(PC방)용 접속기: 설치 없이 127.0.0.1 로 집 서버를 이어 준다
$AuthKey = ''   # Tailscale 인증 키(tskey-auth-...)를 넣으면 로그인 없이 연결. 비워 두면 브라우저 로그인 창이 뜬다.

$ErrorActionPreference = 'Continue'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Here      = $PSScriptRoot
$Mode      = "$($args[0])".Trim().ToLower()
Write-Host '싱글리니지 준비 중입니다. 이 창은 닫지 마세요 (다 끝나면 저절로 닫힙니다).'
$StateDir  = Join-Path $env:LOCALAPPDATA 'SingleLin'
$StateFile = Join-Path $StateDir 'state.txt'
$TsExe     = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
$Desktop   = [Environment]::GetFolderPath('Desktop')
$PlayBat   = Join-Path $Desktop '싱글리니지 접속.bat'
$RemoveBat = Join-Path $Desktop '싱글리니지 지우기.bat'
$AutoYes   = ($env:SL_AUTOYES -eq '1')   # 시험용
$RelayExe  = Join-Path $StateDir 'singlelin-relay.exe'
$RelayStat = Join-Path $StateDir 'relay_status.txt'
$script:Target = $HostIp   # 접속기 모드면 127.0.0.1
$script:RelayProc = $null

function Say($m, $icon = 'Information') { if (-not $AutoYes) { [Windows.Forms.MessageBox]::Show($m, '싱글리니지', 'OK', $icon) | Out-Null } }
function Ask($m) { if ($AutoYes) { return $true }; return ([Windows.Forms.MessageBox]::Show($m, '싱글리니지', 'YesNo', 'Question')) -eq 'Yes' }
function Pump([double]$sec) { $t = [DateTime]::Now.AddSeconds($sec); do { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100 } while ([DateTime]::Now -lt $t) }

function Load-State {
    $h = @{}
    if (Test-Path -LiteralPath $StateFile) {
        foreach ($l in [IO.File]::ReadAllLines($StateFile, [Text.Encoding]::UTF8)) { $i = $l.IndexOf('='); if ($i -gt 0) { $h[$l.Substring(0, $i)] = $l.Substring($i + 1) } }
    }
    return $h
}
function Save-State($h) {
    New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
    [IO.File]::WriteAllLines($StateFile, [string[]]@($h.Keys | ForEach-Object { "$_=$($h[$_])" }), (New-Object Text.UTF8Encoding($false)))
}

$script:Form = $null
function Show-Progress($text, [double]$frac) {
    if (-not $script:Form) {
        $f = New-Object Windows.Forms.Form
        $f.Text = '싱글리니지 — 준비 중'; $f.StartPosition = 'CenterScreen'; $f.FormBorderStyle = 'FixedDialog'; $f.ControlBox = $false; $f.TopMost = $true
        $f.ClientSize = New-Object Drawing.Size(460, 110); $f.Font = New-Object Drawing.Font('Malgun Gothic', 10)
        $script:Lab = New-Object Windows.Forms.Label; $script:Lab.SetBounds(14, 10, 432, 48); $f.Controls.Add($script:Lab)
        $script:Bar = New-Object Windows.Forms.ProgressBar; $script:Bar.SetBounds(14, 64, 432, 26); $script:Bar.Maximum = 1000; $script:Bar.MarqueeAnimationSpeed = 30; $f.Controls.Add($script:Bar)
        $f.Show(); $script:Form = $f
    }
    $script:Lab.Text = $text
    if ($frac -ge 0) { $script:Bar.Style = 'Blocks'; $script:Bar.Value = [int][Math]::Min(1000, [Math]::Max(0, 1000 * $frac)) } else { $script:Bar.Style = 'Marquee' }
    [Windows.Forms.Application]::DoEvents()
}
function Hide-Progress { if ($script:Form) { $script:Form.Close(); $script:Form = $null } }

function Test-Host([int]$port = 5001, [int]$ms = 2000) {
    $t = New-Object Net.Sockets.TcpClient
    try { return $t.ConnectAsync($script:Target, $port).Wait($ms) } catch { return $false } finally { $t.Close() }
}
function Ts-State {
    if (-not (Test-Path -LiteralPath $TsExe)) { return '' }
    try { $j = (& $TsExe status --json 2>$null) | Out-String; if (-not $j.Trim()) { return '' }; return [string]($j | ConvertFrom-Json).BackendState } catch { return '' }
}

# 이어받기 되는 내려받기 (끊기면 20번까지 다시 이음)
function Download-File($url, $dest, $label) {
    $done = 0L
    if (Test-Path -LiteralPath $dest) { $done = (Get-Item -LiteralPath $dest).Length }
    for ($try = 0; $try -lt 20; $try++) {
        try {
            $req = [Net.HttpWebRequest]::Create($url); $req.Timeout = 15000; $req.ReadWriteTimeout = 60000
            if ($url.StartsWith('http://')) { $req.Proxy = $null }
            if ($done -gt 0) { $req.AddRange([long]$done) }
            $resp = $req.GetResponse()
            if ($done -gt 0 -and [int]$resp.StatusCode -ne 206) { $done = 0L }
            $total = $done + $resp.ContentLength
            $in = $resp.GetResponseStream()
            if ($done -gt 0) { $out = New-Object IO.FileStream($dest, [IO.FileMode]::Append, [IO.FileAccess]::Write) } else { $out = [IO.File]::Create($dest) }
            $buf = New-Object byte[] 262144; $tick = 0; $t0 = [DateTime]::Now; $start = $done
            try {
                while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
                    $out.Write($buf, 0, $n); $done += $n
                    if ((++$tick % 8) -eq 0) {
                        $sec = ([DateTime]::Now - $t0).TotalSeconds
                        $spd = 0; if ($sec -gt 0) { $spd = ($done - $start) / 1MB / $sec }
                        Show-Progress ("{0}`n{1:N0} / {2:N0} MB   ({3:N1} MB/초)" -f $label, ($done / 1MB), ($total / 1MB), $spd) ([double]$done / [Math]::Max([double]1, [double]$total))
                    }
                }
            } finally { $out.Close(); $in.Close(); $resp.Close() }
            if ($done -ge $total) { return }
        } catch {
            Show-Progress "$label`n끊겨서 다시 잇는 중… ($($try + 1)/20)" -1; Pump 3
        }
    }
    throw "$label 실패: 인터넷 연결을 확인해 주세요. 이 파일을 다시 누르면 받던 곳부터 이어서 받습니다."
}

function Install-Tailscale {
    $msi = Join-Path $env:TEMP 'singlelin-tailscale.msi'
    Remove-Item -LiteralPath $msi -Force -ErrorAction SilentlyContinue
    Download-File 'https://pkgs.tailscale.com/stable/tailscale-setup-latest-amd64.msi' $msi 'Tailscale 받는 중'
    Show-Progress "Tailscale 설치 중…`n관리자 확인 창이 뜨면 [예]를 눌러 주세요." -1
    try { $p = Start-Process msiexec.exe -Verb RunAs -PassThru -ArgumentList @('/i', "`"$msi`"", '/quiet', '/norestart') }
    catch { throw 'Tailscale 설치를 취소했습니다 (관리자 확인에서 [아니요]).' }
    while (-not $p.HasExited) { Pump 0.5 }
    Remove-Item -LiteralPath $msi -Force -ErrorAction SilentlyContinue
    if (-not (Test-Path -LiteralPath $TsExe)) { throw 'Tailscale 설치가 안 됐습니다. 이 PC에서 프로그램 설치가 막혀 있을 수 있습니다.' }
    for ($i = 0; $i -lt 60 -and -not (Ts-State); $i++) { Show-Progress 'Tailscale 켜는 중…' -1; Pump 1 }
}

# 집 서버에 붙을 때까지 Tailscale 연결. 이번에 로그인했으면 $true
function Connect-Tailnet {
    if ((Ts-State) -eq 'Running') {
        for ($i = 0; $i -lt 10; $i++) { if (Test-Host) { return $false }; Show-Progress '집 서버 찾는 중…' -1; Pump 1 }
    }
    $a = @('up', '--reset')
    if ($AuthKey) { $a += "--auth-key=$AuthKey"; $a += '--hostname=singlelin-guest' }
    $o = Join-Path $env:TEMP 'singlelin_ts_out.txt'; $e = Join-Path $env:TEMP 'singlelin_ts_err.txt'
    $p = Start-Process -FilePath $TsExe -ArgumentList $a -NoNewWindow -PassThru -RedirectStandardOutput $o -RedirectStandardError $e
    $opened = $false; $deadline = [DateTime]::Now.AddMinutes(5)
    while ([DateTime]::Now -lt $deadline) {
        $msg = 'Tailscale 연결 중…'
        if (-not $AuthKey) { $msg += "`n열린 브라우저 창에서 로그인해 주세요 (구글 계정 등)." }
        Show-Progress $msg -1
        if (-not $opened) {
            $txt = ((Get-Content -LiteralPath $o, $e -Raw -ErrorAction SilentlyContinue) -join "`n")
            if ($txt -match 'https://login\.tailscale\.com/\S+') { Start-Process $Matches[0]; $opened = $true }
        }
        if ((Ts-State) -eq 'Running' -and (Test-Host)) { return $true }
        Pump 1
    }
    try { $p.Kill() } catch { }
    throw "집 서버($HostIp)에 연결되지 않습니다.`nTailscale 로그인이 끝났는지, 집 PC와 게임 서버가 켜져 있는지 확인해 주세요."
}

# 설치가 막힌 PC: 접속기(singlelin-relay.exe, 설치·관리자 권한 없음)로 127.0.0.1:5000/5001 → 집 서버
function Start-Relay {
    New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
    Get-Process -Name singlelin-relay -ErrorAction SilentlyContinue | ForEach-Object { try { $_.Kill() } catch { } }
    if (-not (Test-Path -LiteralPath $RelayExe) -or (Get-Item -LiteralPath $RelayExe).Length -lt 1MB) {
        Download-File $RelayUrl $RelayExe '접속기 받는 중 (약 22MB)'
    }
    Remove-Item -LiteralPath $RelayStat -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $StateDir 'relay') -Recurse -Force -ErrorAction SilentlyContinue   # 임시 기기라 매번 새로 로그인 (옛 키가 남으면 로그인 창이 안 뜰 수 있음)
    $script:RelayProc = Start-Process -FilePath $RelayExe -PassThru -WindowStyle Hidden -ArgumentList @('-host', $HostIp, '-dir', "`"$(Join-Path $StateDir 'relay')`"", '-status', "`"$RelayStat`"")
    $script:Target = '127.0.0.1'
    $deadline = [DateTime]::Now.AddMinutes(15)
    while ([DateTime]::Now -lt $deadline) {
        $txt = ''; try { $txt = [IO.File]::ReadAllText($RelayStat) } catch { }
        if ($txt -match 'READY') { return }
        if ($txt -match 'ERR (.+)') { throw "접속기 오류: $($Matches[1].Trim())`n집 PC와 게임 서버가 켜져 있는지 확인해 주세요." }
        if ($script:RelayProc.HasExited) { throw '접속기가 꺼졌습니다. 백신이 막았을 수 있습니다.' }
        if ($txt -match 'AUTH') { Show-Progress "열린 브라우저 창에서 Tailscale에 로그인해 주세요.`n(공유를 수락한 계정. 창이 안 보이면 작업 표시줄의 브라우저를 눌러 보세요)" -1 }
        else { Show-Progress '접속기 켜는 중…' -1 }
        Pump 1
    }
    throw '로그인을 기다리다 시간이 지났습니다. 이 파일을 다시 눌러 주세요.'
}
function Stop-Relay {
    Get-Process -Name singlelin-relay -ErrorAction SilentlyContinue | ForEach-Object { try { $_.Kill(); $_.WaitForExit(3000) | Out-Null } catch { } }
}
# 게임이 접속할 주소 (connect.ps1 이 서버주소.txt 를 읽어 wsock32.dll 에 씀. 패치는 이 파일을 건드리지 않음)
function Set-ServerAddr($dir) {
    $f = Join-Path $dir '서버주소.txt'
    if (-not (Test-Path -LiteralPath $f)) { return }
    [IO.File]::WriteAllText($f, "$($script:Target):5000`r`n", (New-Object Text.UTF8Encoding $false))
}

function Find-GameDir($st) {
    if (Test-Path -LiteralPath (Join-Path $Here 'connect.ps1')) { return $Here }      # 이미 풀어 둔 친구용 폴더 안에서 누른 경우
    if ($st['Dir'] -and (Test-Path -LiteralPath (Join-Path $st['Dir'] '.installed'))) { return $st['Dir'] }
    return $null
}
function Pick-GameDir {
    $need = 8GB
    $c = New-Object IO.DriveInfo($env:LOCALAPPDATA.Substring(0, 1))
    if ($c.AvailableFreeSpace -ge $need) { return (Join-Path $StateDir 'game') }
    foreach ($d in [IO.DriveInfo]::GetDrives()) {
        if ($d.DriveType -eq 'Fixed' -and $d.IsReady -and $d.AvailableFreeSpace -ge $need) { return (Join-Path $d.RootDirectory.FullName 'SingleLin\game') }
    }
    throw '빈 공간이 8GB 이상인 드라이브가 없습니다.'
}
function Install-Game($dir) {
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $zip = Join-Path $Here '싱글리니지_친구용.zip'   # USB 에 같이 넣어 왔으면 그것을 쓴다
    $tmp = $false
    if (-not (Test-Path -LiteralPath $zip)) {
        $zip = Join-Path (Split-Path -Parent $dir) 'download.zip'; $tmp = $true
        Download-File "http://$($script:Target):5001/patch/full" $zip '게임 받는 중 (처음 한 번, 약 3.2GB)'
    }
    Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
    $root = [IO.Path]::GetFullPath($dir).TrimEnd('\') + '\'
    $z = [IO.Compression.ZipFile]::OpenRead($zip)
    try {
        $all = $z.Entries.Count; $i = 0
        foreach ($en in $z.Entries) {
            $i++
            $dst = [IO.Path]::GetFullPath((Join-Path $dir $en.FullName))
            if (-not $dst.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { continue }
            if ($en.FullName.EndsWith('/')) { New-Item -ItemType Directory -Force -Path $dst | Out-Null; continue }
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($en, $dst, $true)
            if (($i % 40) -eq 0) { Show-Progress "압축 푸는 중… $i / $all" ($i / $all) }
        }
    } finally { $z.Dispose() }
    if ($tmp) { Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue }
    [IO.File]::WriteAllText((Join-Path $dir '.installed'), 'ok')
}
function Make-Shortcuts {
    New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
    $mine = Join-Path $StateDir 'oneclick.ps1'
    if ($PSCommandPath -ne $mine) { Copy-Item -LiteralPath $PSCommandPath -Destination $mine -Force }
    $enc = New-Object Text.ASCIIEncoding
    foreach ($m in @(@($PlayBat, 'play'), @($RemoveBat, 'remove'))) {
        [IO.File]::WriteAllText($m[0], "@echo off`r`npowershell -NoProfile -ExecutionPolicy Bypass -File `"%LOCALAPPDATA%\SingleLin\oneclick.ps1`" $($m[1])`r`n", $enc)
    }
}
function Stop-Game($dir) {
    $low = ([IO.Path]::GetFullPath($dir).TrimEnd('\') + '\').ToLower()
    Get-Process -Name lin, pythonw, python -ErrorAction SilentlyContinue |
        Where-Object { try { $_.Path -and $_.Path.ToLower().StartsWith($low) } catch { $false } } |
        ForEach-Object { try { $_.Kill(); $_.WaitForExit(3000) | Out-Null } catch { } }
}
function Run-Game($dir) {
    Hide-Progress
    $conn = Join-Path $dir 'connect.ps1'
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$conn`"")
    $lin = (Join-Path $dir 'SingleLineage\lin.bin').ToLower()
    $seen = $false; $deadline = [DateTime]::Now.AddMinutes(10)
    while ($true) {
        $on = @(Get-Process -Name lin -ErrorAction SilentlyContinue | Where-Object { try { $_.Path -and $_.Path.ToLower() -eq $lin } catch { $false } }).Count -gt 0
        if ($on) { $seen = $true } elseif ($seen -or [DateTime]::Now -gt $deadline) { break }
        Start-Sleep -Seconds 2
    }
}
function Ts-Logout { if (Test-Path -LiteralPath $TsExe) { Start-Process -FilePath $TsExe -ArgumentList 'logout' -WindowStyle Hidden -Wait -ErrorAction SilentlyContinue } }

function Remove-All {
    $st = Load-State
    $what = '게임 파일, 바탕 화면의 싱글리니지 아이콘'
    if ($st['TsByUs'] -eq '1') { $what += ', 이 설치 파일이 깐 Tailscale' }
    if (-not (Ask "싱글리니지를 이 PC에서 지울까요?`n지우는 것: $what`n`n캐릭터·아이템은 집 서버에 있어서 그대로 남습니다.")) { return }
    Show-Progress '지우는 중…' -1
    if ($st['Dir']) { Stop-Game $st['Dir'] }
    Stop-Relay
    if ($st['LoggedInByUs'] -eq '1' -or $st['TsByUs'] -eq '1') { Ts-Logout }
    $left = @()
    if ($st['TsByUs'] -eq '1') {
        Show-Progress "Tailscale 지우는 중…`n관리자 확인 창이 뜨면 [예]를 눌러 주세요." -1
        $u = @(Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' -ErrorAction SilentlyContinue |
            ForEach-Object { Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue } | Where-Object { $_.DisplayName -like 'Tailscale*' -and $_.PSChildName -like '{*}' })
        foreach ($k in $u) {
            try { $p = Start-Process msiexec.exe -Verb RunAs -PassThru -ArgumentList @('/x', $k.PSChildName, '/quiet', '/norestart'); while (-not $p.HasExited) { Pump 0.5 } }
            catch { $left += 'Tailscale (관리자 확인 취소 — 설정 > 앱에서 직접 지우세요)' }
        }
    }
    if ($st['Dir'] -and (Test-Path -LiteralPath $st['Dir'])) {
        Remove-Item -LiteralPath $st['Dir'] -Recurse -Force -ErrorAction SilentlyContinue
        if (Test-Path -LiteralPath $st['Dir']) { $left += $st['Dir'] }
        $parent = Split-Path -Parent $st['Dir']
        if ((Split-Path -Leaf $parent) -eq 'SingleLin' -and $parent -ne $StateDir) { Remove-Item -LiteralPath $parent -Recurse -Force -ErrorAction SilentlyContinue }
    }
    Remove-Item -LiteralPath $StateDir -Recurse -Force -ErrorAction SilentlyContinue
    # 바탕 화면 아이콘 + 처음 받은 설치 파일(다운로드·바탕 화면에 있을 때만) — 이 창이 끝난 뒤 지운다
    $del = @($PlayBat, $RemoveBat)
    $o = $st['Origin']; $dl = Join-Path $env:USERPROFILE 'Downloads'; $oDir = $null
    if ($o -and (Test-Path -LiteralPath $o)) {
        foreach ($okDir in @($Desktop, $dl)) { if ($o.StartsWith($okDir, [StringComparison]::OrdinalIgnoreCase)) { $oDir = $o } }
    }
    if ($oDir) { foreach ($n in @('싱글리니지_원클릭.bat', 'oneclick.ps1')) { $del += (Join-Path $oDir $n) } }
    $del += (Join-Path $dl '싱글리니지_원클릭.zip')
    $del += (Join-Path $dl 'singlelin_oneclick.zip')   # 카톡 안 브라우저 등이 영문 이름으로 저장할 때
    Hide-Progress
    if ($left.Count -gt 0) { Say ("거의 다 지웠습니다. 못 지운 것:`n" + ($left -join "`n")) 'Warning' } else { Say '다 지웠습니다.' }
    $cmd = 'ping -n 3 127.0.0.1 >nul'
    foreach ($d in $del) { if (Test-Path -LiteralPath $d) { $cmd += " & del /f /q `"$d`"" } }
    if ($oDir -and $oDir -ne $Desktop -and $oDir -ne $dl) { $cmd += " & rmdir `"$oDir`"" }   # 비었을 때만 지워짐
    Start-Process cmd.exe -WindowStyle Hidden -ArgumentList @('/c', $cmd)
}

try {
    if ($Mode -eq 'remove') { Remove-All; exit }
    $st = Load-State
    if (-not $st['Dir'] -and -not (Find-GameDir $st)) {
        if (-not (Ask "싱글리니지를 이 PC에 준비합니다 (처음 한 번).`n1) Tailscale 설치·연결  2) 게임 받기(약 3.2GB)  3) 접속`n`n다 놀고 나면 바탕 화면 '싱글리니지 지우기'로 깨끗이 지울 수 있습니다. 시작할까요?")) { exit }
    }
    # 1) 집 서버까지 길 만들기 (이미 붙으면 건너뜀)
    if ($st['Relay'] -eq '1' -and -not (Test-Path -LiteralPath $TsExe)) { Start-Relay }     # 전에 접속기로 했던 PC
    elseif (-not (Test-Host)) {
        $useRelay = $false
        if (-not (Test-Path -LiteralPath $TsExe)) {
            try { Install-Tailscale; $st['TsByUs'] = '1'; Save-State $st }
            catch { $useRelay = $true }   # PC방처럼 설치가 막힘 → 설치 없는 접속기
        }
        if ($useRelay) { $st['Relay'] = '1'; Save-State $st; Start-Relay }
        elseif (Connect-Tailnet) { $st['LoggedInByUs'] = '1'; Save-State $st }
    }
    # 2) 게임 파일 (처음 한 번)
    $dir = Find-GameDir $st
    if (-not $dir) {
        if ($st['Dir']) { $dir = $st['Dir'] } else { $dir = Pick-GameDir }   # 받다 끊긴 적 있으면 같은 곳에 이어서
        $st['Dir'] = $dir; $st['Origin'] = $Here; Save-State $st
        Install-Game $dir
        Make-Shortcuts
        Hide-Progress
        Say "준비 끝!`n다음부터는 바탕 화면 '싱글리니지 접속'을 누르세요.`n다 놀고 나면 '싱글리니지 지우기'를 누르면 깨끗이 지워집니다.`n`n[확인]을 누르면 게임을 켭니다."
    } elseif ($dir -eq $st['Dir'] -and -not (Test-Path -LiteralPath $RemoveBat)) {
        Make-Shortcuts
    }
    Set-ServerAddr $dir
    if ($Mode -eq 'nogame') { Hide-Progress; Stop-Relay; exit }   # 시험용
    # 3) 게임 — 끄면 이번에 로그인한 Tailscale 은 로그아웃 (다음에 누르면 다시 연결)
    Run-Game $dir
    Stop-Relay   # 접속기 기기는 임시라 꺼지면 Tailscale 목록에서 저절로 사라짐
    if ($st['LoggedInByUs'] -eq '1') { Ts-Logout }
} catch {
    Hide-Progress
    Stop-Relay
    try { [IO.File]::WriteAllText((Join-Path $env:TEMP 'singlelin_error.txt'), ($_ | Out-String) + $_.ScriptStackTrace) } catch { }
    Say ("문제가 생겼습니다:`n" + $_.Exception.Message) 'Error'
}
