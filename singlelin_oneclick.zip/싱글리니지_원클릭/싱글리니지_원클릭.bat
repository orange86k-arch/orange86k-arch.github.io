@echo off
chcp 65001 >nul
if not exist "%~dp0oneclick.ps1" (
  echo.
  echo  [!] 압축을 먼저 풀어 주세요. 싱글리니지_원클릭.bat 과 oneclick.ps1 이 같은 폴더에 있어야 합니다.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0oneclick.ps1" %*
